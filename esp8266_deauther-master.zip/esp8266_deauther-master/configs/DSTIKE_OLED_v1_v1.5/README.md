# DSTIKE Deauther OLED v1 - v1.5

|  |  |
| - | - |
| LED Type | Digital |
| LED R | GPIO 16 |
| LED G | disabled |
| LED B | GPIO 2 |
| Highlight LED | disabled |
| Display and buttons enabled | YES |
| Display Driver | SSD1306  |
| Display SDA | GPIO 5 (D1) |
| Display SCL | GPIO 4 (D2) |
| Flip Display | NO |
| Button Up |GPIO 12 |
| Button Down | GPIO 13 |
| Button A | GPIO 14 |
| Button B |disabled |